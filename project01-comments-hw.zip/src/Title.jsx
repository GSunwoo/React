function Title() {
  return (<>
    <div className="card mb-4">
          <div className="card-body">
              <h5 className="card-title">댓글 작성 구현하기</h5>
              <p className="card-text">
                  구현할 기능은 댓글작성, 좋아요, 수정, 삭제입니다. <br/>
                  기능 구현은 아래 댓글 작성부터 하면 됩니다. 
              </p>
          </div>
      </div>
  </>); 
}
export default Title;